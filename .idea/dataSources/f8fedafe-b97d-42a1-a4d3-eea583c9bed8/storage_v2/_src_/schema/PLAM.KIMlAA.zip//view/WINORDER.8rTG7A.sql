create view WINORDER as
select C.artworkID, C.artist, C.title, C.category, W.winner, W.winorder
    from
        (select artworkID, firstName || '' || lastName as artist, title, category
        from Artwork A
            join Participant P on A.creatorEmail = P.email) C
            join
                (select artworkID, firstName ||''|| lastName as winner, title, category, winOrder
                from Artwork A join Participant P on A.winnerEmail = P.email) W
            on C.artworkID = W.artworkID
    order by winOrder
/

