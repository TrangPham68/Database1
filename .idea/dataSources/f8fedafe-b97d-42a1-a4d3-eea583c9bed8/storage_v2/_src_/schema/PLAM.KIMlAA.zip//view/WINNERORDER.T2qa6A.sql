create view WINNERORDER as
select winOrder, firstName || '' || lastName as artist, title, category, firstName || '' || lastName as winner
    from Artwork A
        join Participant P on A.winnerEmail = P.email
        order by winOrder
/

